package com.example.tictactoegame;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import java.util.ArrayList;
import java.util.List;

public class GameDatabaseHelper extends SQLiteOpenHelper {

    // Database Information
    private static final String DATABASE_NAME = "TicTacToeGame.db";
    private static final int DATABASE_VERSION = 1;

    // Table Name
    private static final String TABLE_GAME_RECORDS = "game_records";

    // Table Columns
    private static final String COLUMN_ID = "id";
    private static final String COLUMN_USERNAME = "username";
    private static final String COLUMN_ROUND_NUMBER = "round_number";
    private static final String COLUMN_PLAYER_NUMBERS = "player_numbers";
    private static final String COLUMN_SYSTEM_TIME = "system_time";
    private static final String COLUMN_WINNER = "winner";

    // Create Table Query
    private static final String CREATE_TABLE_GAME_RECORDS =
            "CREATE TABLE " + TABLE_GAME_RECORDS + "(" +
                    COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT," +
                    COLUMN_USERNAME + " TEXT," +
                    COLUMN_ROUND_NUMBER + " INTEGER," +
                    COLUMN_PLAYER_NUMBERS + " TEXT," +
                    COLUMN_SYSTEM_TIME + " TEXT," +
                    COLUMN_WINNER + " TEXT" + ")";

    public GameDatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CREATE_TABLE_GAME_RECORDS);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_GAME_RECORDS);
        onCreate(db);
    }

    // Insert a new game record
    public long insertGameRecord(GameRecord gameRecord) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();

        values.put(COLUMN_USERNAME, gameRecord.getUsername());
        values.put(COLUMN_ROUND_NUMBER, gameRecord.getRoundNumber());
        values.put(COLUMN_PLAYER_NUMBERS, gameRecord.getPlayerNumbers());
        values.put(COLUMN_SYSTEM_TIME, gameRecord.getSystemTime());
        values.put(COLUMN_WINNER, gameRecord.getWinner());

        long id = db.insert(TABLE_GAME_RECORDS, null, values);
        db.close();
        return id;
    }

    // Get all game records
    public List<GameRecord> getAllGameRecords() {
        List<GameRecord> gameRecords = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();

        String query = "SELECT * FROM " + TABLE_GAME_RECORDS + " ORDER BY " + COLUMN_ROUND_NUMBER + " DESC";
        Cursor cursor = db.rawQuery(query, null);

        if (cursor.moveToFirst()) {
            do {
                GameRecord record = new GameRecord();
                record.setId(cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_ID)));
                record.setUsername(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_USERNAME)));
                record.setRoundNumber(cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_ROUND_NUMBER)));
                record.setPlayerNumbers(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_PLAYER_NUMBERS)));
                record.setSystemTime(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_SYSTEM_TIME)));
                record.setWinner(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_WINNER)));

                gameRecords.add(record);
            } while (cursor.moveToNext());
        }
        cursor.close();
        db.close();
        return gameRecords;
    }

    // Get the maximum round number for a user
    public int getMaxRoundNumber(String username) {
        SQLiteDatabase db = this.getReadableDatabase();
        int maxRound = 0;

        String query = "SELECT MAX(" + COLUMN_ROUND_NUMBER + ") FROM " + TABLE_GAME_RECORDS +
                " WHERE " + COLUMN_USERNAME + " = ?";
        Cursor cursor = db.rawQuery(query, new String[]{username});

        if (cursor.moveToFirst()) {
            maxRound = cursor.getInt(0);
        }
        cursor.close();
        db.close();
        return maxRound;
    }

    // Get game records by username
    public List<GameRecord> getGameRecordsByUsername(String username) {
        List<GameRecord> gameRecords = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();

        String query = "SELECT * FROM " + TABLE_GAME_RECORDS +
                " WHERE " + COLUMN_USERNAME + " = ?" +
                " ORDER BY " + COLUMN_ROUND_NUMBER + " DESC";
        Cursor cursor = db.rawQuery(query, new String[]{username});

        if (cursor.moveToFirst()) {
            do {
                GameRecord record = new GameRecord();
                record.setId(cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_ID)));
                record.setUsername(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_USERNAME)));
                record.setRoundNumber(cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_ROUND_NUMBER)));
                record.setPlayerNumbers(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_PLAYER_NUMBERS)));
                record.setSystemTime(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_SYSTEM_TIME)));
                record.setWinner(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_WINNER)));

                gameRecords.add(record);
            } while (cursor.moveToNext());
        }
        cursor.close();
        db.close();
        return gameRecords;
    }

    // Delete all records (for testing/reset)
    public void deleteAllRecords() {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(TABLE_GAME_RECORDS, null, null);
        db.close();
    }
}
