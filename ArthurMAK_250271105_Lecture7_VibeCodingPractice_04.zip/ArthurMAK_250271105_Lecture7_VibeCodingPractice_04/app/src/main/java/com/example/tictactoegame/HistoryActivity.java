package com.example.tictactoegame;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import java.util.List;

public class HistoryActivity extends AppCompatActivity {

    private ListView historyListView;
    private TextView historyTitleTextView;
    private TextView emptyHistoryTextView;
    private Button backButton;
    private GameDatabaseHelper databaseHelper;
    private String currentUsername;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_history);

        initializeViews();
        setupBackButton();
        displayGameHistory();
    }

    private void initializeViews() {
        historyListView = findViewById(R.id.historyListView);
        historyTitleTextView = findViewById(R.id.historyTitleTextView);
        emptyHistoryTextView = findViewById(R.id.emptyHistoryTextView);
        backButton = findViewById(R.id.backButton);

        databaseHelper = new GameDatabaseHelper(this);

        // Get current username
        currentUsername = getSharedPreferences("login.xml", MODE_PRIVATE)
                .getString("username", "Unknown");
    }

    private void setupBackButton() {
        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish(); // Close this activity and return to MainActivity
            }
        });
    }

    private void displayGameHistory() {
        List<GameRecord> gameRecords = databaseHelper.getGameRecordsByUsername(currentUsername);

        if (gameRecords.isEmpty()) {
            historyTitleTextView.setText("Game History for " + currentUsername);
            emptyHistoryTextView.setVisibility(View.VISIBLE);
            historyListView.setVisibility(View.GONE);
        } else {
            historyTitleTextView.setText("Game History for " + currentUsername + " (" + gameRecords.size() + " games)");
            emptyHistoryTextView.setVisibility(View.GONE);
            historyListView.setVisibility(View.VISIBLE);

            String[] historyItems = new String[gameRecords.size()];
            for (int i = 0; i < gameRecords.size(); i++) {
                GameRecord record = gameRecords.get(i);
                String result = "";
                switch (record.getWinner()) {
                    case "PLAYER":
                        result = "🎉 You Won!";
                        break;
                    case "COMPUTER":
                        result = "🤖 Computer Won";
                        break;
                    case "DRAW":
                        result = "🤝 Draw";
                        break;
                }

                historyItems[i] = "Round " + record.getRoundNumber() +
                        " - " + result +
                        "\n" + record.getSystemTime();
            }

            ArrayAdapter<String> adapter = new ArrayAdapter<>(
                    this,
                    android.R.layout.simple_list_item_1,
                    historyItems
            );

            historyListView.setAdapter(adapter);
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (databaseHelper != null) {
            databaseHelper.close();
        }
    }
}