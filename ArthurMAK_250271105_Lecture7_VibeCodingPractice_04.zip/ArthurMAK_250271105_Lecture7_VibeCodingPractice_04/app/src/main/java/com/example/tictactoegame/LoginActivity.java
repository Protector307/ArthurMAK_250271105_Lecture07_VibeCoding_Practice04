package com.example.tictactoegame;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {

    private EditText usernameEditText, passwordEditText;
    private Button loginButton;
    private SharedPreferences sharedPreferences;

    // Default credentials
    private static final String DEFAULT_USERNAME = "Arthur";
    private static final String DEFAULT_PASSWORD = "123456";
    private static final String PREFS_NAME = "login.xml";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        initializeViews();
        setupSharedPreferences();
        setupLoginButton();
    }

    private void initializeViews() {
        usernameEditText = findViewById(R.id.usernameEditText);
        passwordEditText = findViewById(R.id.passwordEditText);
        loginButton = findViewById(R.id.loginButton);
    }

    private void setupSharedPreferences() {
        sharedPreferences = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);

        // Check if SharedPreferences already exists
        boolean prefsExist = sharedPreferences.contains("username");

        if (!prefsExist) {
            // Set default credentials if SharedPreferences doesn't exist
            SharedPreferences.Editor editor = sharedPreferences.edit();
            editor.putString("username", DEFAULT_USERNAME);
            editor.putString("password", DEFAULT_PASSWORD);
            editor.apply();
        }
        // If SharedPreferences exists, use the stored values automatically
    }

    private void setupLoginButton() {
        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                attemptLogin();
            }
        });
    }

    private void attemptLogin() {
        String inputUsername = usernameEditText.getText().toString().trim();
        String inputPassword = passwordEditText.getText().toString().trim();

        // Retrieve stored credentials
        String storedUsername = sharedPreferences.getString("username", "");
        String storedPassword = sharedPreferences.getString("password", "");

        if (inputUsername.equals(storedUsername) && inputPassword.equals(storedPassword)) {
            // Login successful - navigate to MainActivity
            Intent intent = new Intent(LoginActivity.this, MainActivity.class);
            startActivity(intent);
            finish(); // Close login activity
        } else {
            // Login failed - show error dialog
            showErrorDialog();
        }
    }

    private void showErrorDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Login Failed")
                .setMessage("Your data is incorrect!! Enter again!")
                .setPositiveButton("OK", null)
                .setIcon(android.R.drawable.ic_dialog_alert)
                .show();
    }
}