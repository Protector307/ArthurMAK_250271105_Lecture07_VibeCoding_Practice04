package com.example.tictactoegame;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import java.util.Random;

public class MainActivity extends AppCompatActivity {

    private TextView[][] cells;
    private boolean isPlayerX = true;
    private boolean isGameActive = true;
    private Button resetButton;
    private Button historyButton;
    private TextView titleTextView;
    private TextView roundTextView;
    private ImageView configImageView;

    private Random random;
    private Handler computerHandler;

    // Game state constants
    private static final String PLAYER_X = "X";
    private static final String PLAYER_O = "O";
    private static final String EMPTY_CELL = "";
    private static final int COMPUTER_DELAY = 3000; // 3 seconds

    // Round counter and database
    private int currentRound = 0;
    private String currentUsername;
    private GameDatabaseHelper databaseHelper;
    private SharedPreferences sharedPreferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        initializeViews();
        initializeGame();
        setupClickListeners();
        setupConfigImageView();
        setupHistoryButton();
        startNewRound();
    }

    private void initializeViews() {
        resetButton = findViewById(R.id.resetButton);
        historyButton = findViewById(R.id.historyButton);
        titleTextView = findViewById(R.id.titleTextView);
        roundTextView = findViewById(R.id.roundTextView);
        configImageView = findViewById(R.id.configImageView);

        // Initialize the 3x3 grid
        cells = new TextView[3][3];
        cells[0][0] = findViewById(R.id.cell00);
        cells[0][1] = findViewById(R.id.cell01);
        cells[0][2] = findViewById(R.id.cell02);
        cells[1][0] = findViewById(R.id.cell10);
        cells[1][1] = findViewById(R.id.cell11);
        cells[1][2] = findViewById(R.id.cell12);
        cells[2][0] = findViewById(R.id.cell20);
        cells[2][1] = findViewById(R.id.cell21);
        cells[2][2] = findViewById(R.id.cell22);
    }

    private void initializeGame() {
        random = new Random();
        computerHandler = new Handler();
        databaseHelper = new GameDatabaseHelper(this);

        // Get current username from SharedPreferences
        sharedPreferences = getSharedPreferences("login.xml", MODE_PRIVATE);
        currentUsername = sharedPreferences.getString("username", "Unknown");

        // Get the maximum round number from database and set next round
        int maxRound = databaseHelper.getMaxRoundNumber(currentUsername);
        currentRound = maxRound;

        setupGameBoard();
    }

    private void setupConfigImageView() {
        configImageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Navigate to ConfigActivity
                Intent intent = new Intent(MainActivity.this, ConfigActivity.class);
                startActivity(intent);
            }
        });
    }

    private void setupHistoryButton() {
        historyButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Navigate to HistoryActivity
                Intent intent = new Intent(MainActivity.this, HistoryActivity.class);
                startActivity(intent);
            }
        });
    }

    private void startNewRound() {
        currentRound++;
        updateRoundDisplay();
        setupGameBoard();
    }

    private void updateRoundDisplay() {
        roundTextView.setText("Round: " + currentRound);
    }

    private void setupGameBoard() {
        // Clear all cells
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                cells[i][j].setText(EMPTY_CELL);
                cells[i][j].setBackgroundResource(R.drawable.cell_border);
                cells[i][j].setClickable(true);
            }
        }
        isPlayerX = true;
        isGameActive = true;
        titleTextView.setText("Tic Tac Toe - Your Turn (X)");
    }

    private void setupClickListeners() {
        // Set click listeners for all cells
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                final int row = i;
                final int col = j;
                cells[i][j].setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (isGameActive && isPlayerX) {
                            onPlayerMove(row, col);
                        }
                    }
                });
            }
        }

        // Reset button click listener
        resetButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startNewRound();
            }
        });
    }

    private void onPlayerMove(int row, int col) {
        if (cells[row][col].getText().toString().equals(EMPTY_CELL)) {
            // Player makes move
            makeMove(row, col, PLAYER_X);

            // Check if game continues
            if (isGameActive) {
                // Switch to computer's turn
                isPlayerX = false;
                titleTextView.setText("Computer thinking...");

                // Computer makes move after 3 seconds delay
                computerHandler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        if (isGameActive && !isPlayerX) {
                            computerMove();
                        }
                    }
                }, COMPUTER_DELAY);
            }
        }
    }

    private void makeMove(int row, int col, String player) {
        TextView cell = cells[row][col];
        cell.setText(player);

        if (player.equals(PLAYER_X)) {
            cell.setTextColor(getResources().getColor(android.R.color.holo_red_dark));
        } else {
            cell.setTextColor(getResources().getColor(android.R.color.holo_blue_dark));
        }
        cell.setClickable(false);

        checkGameStatus();
    }

    private void computerMove() {
        if (!isGameActive) return;

        // Get all available empty cells
        int emptyCells = countEmptyCells();
        if (emptyCells == 0) return;

        // Randomly select an empty cell
        int randomIndex = random.nextInt(emptyCells);
        int cellCounter = 0;

        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                if (cells[i][j].getText().toString().equals(EMPTY_CELL)) {
                    if (cellCounter == randomIndex) {
                        makeMove(i, j, PLAYER_O);
                        isPlayerX = true;
                        if (isGameActive) {
                            titleTextView.setText("Tic Tac Toe - Your Turn (X)");
                        }
                        return;
                    }
                    cellCounter++;
                }
            }
        }
    }

    private int countEmptyCells() {
        int count = 0;
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                if (cells[i][j].getText().toString().equals(EMPTY_CELL)) {
                    count++;
                }
            }
        }
        return count;
    }

    private void checkGameStatus() {
        String winner = checkWinner();

        if (winner != null) {
            isGameActive = false;
            String winnerType;
            String winningPattern = getWinningPattern();

            if (winner.equals(PLAYER_X)) {
                titleTextView.setText("Congratulations! You Win! 🎉");
                winnerType = "PLAYER";
            } else if (winner.equals(PLAYER_O)) {
                titleTextView.setText("Computer Wins! Try Again! 🤖");
                winnerType = "COMPUTER";
            } else {
                titleTextView.setText("It's a Draw! 🤝");
                winnerType = "DRAW";
                winningPattern = "DRAW";
            }

            // Save game record to database
            saveGameRecord(winnerType, winningPattern);
            disableAllCells();
        } else if (countEmptyCells() == 0) {
            // No winner but board is full
            isGameActive = false;
            titleTextView.setText("It's a Draw! 🤝");

            // Save draw game record to database
            saveGameRecord("DRAW", "DRAW");
            disableAllCells();
        }
    }

    private String getWinningPattern() {
        // For Tic Tac Toe, we'll store the board state as the "winning pattern"
        StringBuilder pattern = new StringBuilder();
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                String cellValue = cells[i][j].getText().toString();
                if (cellValue.isEmpty()) {
                    pattern.append("_");
                } else {
                    pattern.append(cellValue);
                }
                if (i != 2 || j != 2) {
                    pattern.append(",");
                }
            }
        }
        return pattern.toString();
    }

    private void saveGameRecord(String winner, String winningPattern) {
        GameRecord gameRecord = new GameRecord(
                currentUsername,
                currentRound,
                winningPattern,
                winner
        );

        long recordId = databaseHelper.insertGameRecord(gameRecord);

        if (recordId != -1) {
            // Successfully saved to database
            System.out.println("Game record saved successfully! Round: " + currentRound);
        } else {
            System.out.println("Failed to save game record!");
        }
    }

    private String checkWinner() {
        // Check rows
        for (int i = 0; i < 3; i++) {
            if (!cells[i][0].getText().toString().isEmpty() &&
                    cells[i][0].getText().toString().equals(cells[i][1].getText().toString()) &&
                    cells[i][0].getText().toString().equals(cells[i][2].getText().toString())) {
                return cells[i][0].getText().toString();
            }
        }

        // Check columns
        for (int i = 0; i < 3; i++) {
            if (!cells[0][i].getText().toString().isEmpty() &&
                    cells[0][i].getText().toString().equals(cells[1][i].getText().toString()) &&
                    cells[0][i].getText().toString().equals(cells[2][i].getText().toString())) {
                return cells[0][i].getText().toString();
            }
        }

        // Check diagonals
        if (!cells[0][0].getText().toString().isEmpty() &&
                cells[0][0].getText().toString().equals(cells[1][1].getText().toString()) &&
                cells[0][0].getText().toString().equals(cells[2][2].getText().toString())) {
            return cells[0][0].getText().toString();
        }

        if (!cells[0][2].getText().toString().isEmpty() &&
                cells[0][2].getText().toString().equals(cells[1][1].getText().toString()) &&
                cells[0][2].getText().toString().equals(cells[2][0].getText().toString())) {
            return cells[0][2].getText().toString();
        }

        return null;
    }

    private void disableAllCells() {
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                cells[i][j].setClickable(false);
            }
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        // Clean up handler and database to prevent memory leaks
        if (computerHandler != null) {
            computerHandler.removeCallbacksAndMessages(null);
        }
        if (databaseHelper != null) {
            databaseHelper.close();
        }
    }
}