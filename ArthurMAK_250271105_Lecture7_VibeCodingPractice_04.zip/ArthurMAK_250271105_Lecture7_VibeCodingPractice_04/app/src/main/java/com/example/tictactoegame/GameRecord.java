package com.example.tictactoegame;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class GameRecord {
    private int id;
    private String username;
    private int roundNumber;
    private String playerNumbers; // For Tic Tac Toe, this will store the winning pattern
    private String systemTime;
    private String winner; // "PLAYER" or "COMPUTER" or "DRAW"

    // Default constructor
    public GameRecord() {}

    // Constructor with parameters
    public GameRecord(String username, int roundNumber, String playerNumbers, String winner) {
        this.username = username;
        this.roundNumber = roundNumber;
        this.playerNumbers = playerNumbers;
        this.winner = winner;
        this.systemTime = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(new Date());
    }

    // Getters and Setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getUsername() { return username; }
    public void setUsername(String username) { this.username = username; }

    public int getRoundNumber() { return roundNumber; }
    public void setRoundNumber(int roundNumber) { this.roundNumber = roundNumber; }

    public String getPlayerNumbers() { return playerNumbers; }
    public void setPlayerNumbers(String playerNumbers) { this.playerNumbers = playerNumbers; }

    public String getSystemTime() { return systemTime; }
    public void setSystemTime(String systemTime) { this.systemTime = systemTime; }

    public String getWinner() { return winner; }
    public void setWinner(String winner) { this.winner = winner; }

    @Override
    public String toString() {
        return "GameRecord{" +
                "id=" + id +
                ", username='" + username + '\'' +
                ", roundNumber=" + roundNumber +
                ", playerNumbers='" + playerNumbers + '\'' +
                ", systemTime='" + systemTime + '\'' +
                ", winner='" + winner + '\'' +
                '}';
    }
}
