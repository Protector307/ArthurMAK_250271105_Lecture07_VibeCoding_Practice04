package com.example.tictactoegame;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

public class ConfigActivity extends AppCompatActivity {

    private EditText existingUsernameEditText, existingPasswordEditText;
    private EditText newUsernameEditText, newPasswordEditText;
    private Button confirmButton;
    private SharedPreferences sharedPreferences;

    private static final String PREFS_NAME = "login.xml";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_config);

        initializeViews();
        setupSharedPreferences();
        setupConfirmButton();
    }

    private void initializeViews() {
        existingUsernameEditText = findViewById(R.id.existingUsernameEditText);
        existingPasswordEditText = findViewById(R.id.existingPasswordEditText);
        newUsernameEditText = findViewById(R.id.newUsernameEditText);
        newPasswordEditText = findViewById(R.id.newPasswordEditText);
        confirmButton = findViewById(R.id.confirmButton);
    }

    private void setupSharedPreferences() {
        sharedPreferences = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
    }

    private void setupConfirmButton() {
        confirmButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                validateAndUpdateCredentials();
            }
        });
    }

    private void validateAndUpdateCredentials() {
        String inputExistingUsername = existingUsernameEditText.getText().toString().trim();
        String inputExistingPassword = existingPasswordEditText.getText().toString().trim();
        String inputNewUsername = newUsernameEditText.getText().toString().trim();
        String inputNewPassword = newPasswordEditText.getText().toString().trim();

        // Retrieve stored credentials
        String storedUsername = sharedPreferences.getString("username", "");
        String storedPassword = sharedPreferences.getString("password", "");

        // Check if existing credentials are correct
        if (!inputExistingUsername.equals(storedUsername) || !inputExistingPassword.equals(storedPassword)) {
            showErrorDialog("Existing username/password is not correct!");
            return;
        }

        // Check if new credentials are entered
        if (inputNewUsername.isEmpty() && inputNewPassword.isEmpty()) {
            showErrorDialog("New username/password is not entered! Data is remained unchanged");
            return;
        }

        // Update credentials
        SharedPreferences.Editor editor = sharedPreferences.edit();

        if (!inputNewUsername.isEmpty()) {
            editor.putString("username", inputNewUsername);
        }
        if (!inputNewPassword.isEmpty()) {
            editor.putString("password", inputNewPassword);
        }

        boolean success = editor.commit();

        if (success) {
            showSuccessDialog("New username/password is confirmed! Data is updated");

            // Delay for 2 seconds and return to MainActivity
            new Handler().postDelayed(new Runnable() {
                @Override
                public void run() {
                    Intent intent = new Intent(ConfigActivity.this, MainActivity.class);
                    startActivity(intent);
                    finish();
                }
            }, 2000);
        } else {
            showErrorDialog("Failed to update credentials!");
        }
    }

    private void showErrorDialog(String message) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Error")
                .setMessage(message)
                .setPositiveButton("OK", null)
                .setIcon(android.R.drawable.ic_dialog_alert)
                .show();
    }

    private void showSuccessDialog(String message) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Success")
                .setMessage(message)
                .setPositiveButton("OK", null)
                .setIcon(android.R.drawable.ic_dialog_info)
                .show();
    }
}